﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog dilg = new OpenFileDialog();
            dilg.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm";
            if(dilg.ShowDialog()== DialogResult.OK)
            {
                string filepath = dilg.FileName;
                textBox1.Text = filepath;
                LoadData(filepath, ".xlsx", "yes");
            }
        }
        public void LoadData(string fpath, string ext, string hdr)
        {

            string con = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0};Extended Properties='Excel 12.0';";
            con = string.Format(con,fpath, "yes");
            OleDbConnection Excelconnect = new OleDbConnection(con);
            Excelconnect.Open();
            DataTable dtexcel = Excelconnect.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
            string exsheetname = dtexcel.Rows[0]["TABLE_NAME"].ToString();
            OleDbCommand com = new OleDbCommand("Select * from [" +exsheetname+ "]",Excelconnect);
            OleDbDataAdapter oData = new OleDbDataAdapter(com);
            DataTable dt = new DataTable();
            oData.Fill(dt);
            Excelconnect.Close();
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int lastColumnIndex = dataGridView1.Columns.Count - 1; // Chỉ số cột cuối cùng
            // Duyệt qua từng hàng trong DataGridView
            var fileNamePart = @"Test.txt";
            var fullPath = Path.Combine(@"D:\\", fileNamePart);
            Encoding encoding = Encoding.GetEncoding("ISO-8859-1"); //Or any other Encoding
            if (!File.Exists(fullPath))
            {
                using (var fs = new FileStream(fullPath, FileMode.CreateNew, FileAccess.Write))
                {
                }
            }
            else
                File.WriteAllText(fullPath, String.Empty);

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow) // Kiểm tra xem hàng không phải là hàng mới (thường là hàng cuối cùng để thêm dữ liệu mới)
                {
                    var cellValue = row.Cells[lastColumnIndex].Value; // Lấy giá trị của ô trong cột cuối cùng
                    for (int i =0; i<2; i++)
                    {

                        if (i==0)
                        {
                            using (var sw1 = new StreamWriter(fullPath, true))
                            {
                                sw1.Write("\nHEX:");
                            }
                        }
                        else
                        {
                            using (var sw1 = new StreamWriter(fullPath, true))
                            {
                                sw1.Write("\nDEC:");
                            }
                        }
                        string cellvaluetest = (string)cellValue;
                        TowString(cellvaluetest, fullPath,i);
                    }
                    using (var sw1 = new StreamWriter(fullPath, true))
                    {
                        sw1.Write("\n-------------------------------------------------------------------------------");
                    }
                }
            }
            MessageBox.Show("Cover Hex To Dex Success");
        }

        public void TowString(string value,string fullPath,int Dec)
        {
            for (int i = 0; i < value.Length; i += 2)
            {
                // Kiểm tra xem có đủ 2 ký tự để lấy ra không
                if (i + 1 < value.Length)
                {
                    string pair = value.Substring(i, 2);
                    CoverHex(pair, fullPath, Dec);
                    //CoverDec(pair);
                }
                else
                {
                    // Nếu chỉ còn lại 1 ký tự, in ra hoặc xử lý theo yêu cầu của bạn
                    string pair = value.Substring(i, 1);
                    CoverHex(pair, fullPath, Dec);
                    //CoverDec(pair);
                }
            }
        }

        public void CoverHex(string input,string fullPath, int Dec)
        {
            //Open the File
            if (Dec == 0)
            {
                using (var sw1 = new StreamWriter(fullPath, true))
                {
                    sw1.Write(input + " ");
                }
            }
            else
            {
                using (var sw1 = new StreamWriter(fullPath, true))
                {
                    int decValue = int.Parse(input, System.Globalization.NumberStyles.HexNumber);
                    sw1.Write(decValue + " ");
                }
            }
        }
    }
}